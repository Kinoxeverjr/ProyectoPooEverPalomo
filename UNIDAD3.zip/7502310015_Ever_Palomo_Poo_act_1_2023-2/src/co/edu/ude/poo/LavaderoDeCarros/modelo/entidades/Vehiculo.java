package co.edu.ude.poo.LavaderoDeCarros.modelo.entidades;


public class Vehiculo {
    
    private String Placa;
    private String color;
    private int modelo;
    private String marca;

    public Vehiculo(String Placa, String color, int modelo, String marca) {
        this.Placa = Placa;
        this.color = color;
        this.modelo = modelo;
        this.marca = marca;
    }

    public Vehiculo() {
    }

    public String getPlaca() {
        return Placa;
    }

    public void setPlaca(String Placa) {
        this.Placa = Placa;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getModelo() {
        return modelo;
    }

    public void setModelo(int modelo) {
        this.modelo = modelo;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Carro{");
        sb.append("Placa=").append(Placa);
        sb.append(", color=").append(color);
        sb.append(", modelo=").append(modelo);
        sb.append(", marca=").append(marca);
        sb.append('}');
        return sb.toString();
    }

    
    
    
}
