package co.edu.ude.poo.LavaderoDeCarros.modelo.crud;

import co.edu.ude.poo.LavaderoDeCarros.modelo.entidades.Empresa;
import java.util.ArrayList;
import java.util.List;


public class EmpresaCrud {
    public static List<Empresa> listaEmpresas = new ArrayList<>();

        public int agregarEmpresa (Empresa empresa) throws Exception {
            for (Empresa e : listaEmpresas){
                if (empresa.getNumeroDeRegistro() == e.getNumeroDeRegistro() ) {
                    throw new Exception ("La empresa con numero de registro: "+ e.getNumeroDeRegistro() + "ya existe");
                }
            }
            listaEmpresas.add(empresa);
            return listaEmpresas.size();
            
    }

public Empresa buscarEmpresa (int numeroDeRegistro) throws Exception {
    Empresa empresa = null;
    for (Empresa e : listaEmpresas) {
        if (e.getNumeroDeRegistro() == numeroDeRegistro) {
            empresa = e;
            break;
            }
    }
    if (empresa == null){
    throw new Exception ("La empresa con numero de registro: " + numeroDeRegistro + "ya existe");
    }
    return empresa;
        
}

public void borrarEmpresa ( int NumeroDeRegistro) throws Exception {
    Empresa empresa = null;
    for (Empresa e : listaEmpresas) {
        if (e.getNumeroDeRegistro() == NumeroDeRegistro) {
            empresa = e;
            break;
        }
    }
    if (empresa == null) {
        throw new Exception ("La empresa con numero de registro: " + NumeroDeRegistro + "no esta registrado");
        
    }
    listaEmpresas.remove(empresa);
  }
        public void actualizarEmpresa(int numeroDeRegistro, Empresa nuevaEmpresa) throws Exception {
    Empresa empresaOriginal = buscarEmpresa(numeroDeRegistro);
    if (empresaOriginal != null) {
            empresaOriginal.setNombreEmpresa(nuevaEmpresa.getNombreEmpresa());
            empresaOriginal.setProducto(nuevaEmpresa.getProducto());
            empresaOriginal.setPrecioProductoEmpresa(nuevaEmpresa.getPrecioProductoEmpresa());
            empresaOriginal.setFechaDeEntrega(nuevaEmpresa.getFechaDeEntrega());
        } else {
            throw new Exception("EMPRESA NO SE PUDO ACTUALIZAR");
        }
    }


}
