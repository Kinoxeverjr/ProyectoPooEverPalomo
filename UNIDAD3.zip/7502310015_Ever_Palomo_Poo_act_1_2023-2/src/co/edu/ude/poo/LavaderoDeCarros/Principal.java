
package co.edu.ude.poo.LavaderoDeCarros;

import co.edu.ude.poo.LavaderoDeCarros.modelo.crud.*;
import co.edu.ude.poo.LavaderoDeCarros.modelo.entidades.*;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;


public class Principal {

    public static void main(String[] args) throws Exception{
        
        
        ArrayList <Vehiculo> listaVehiculos = new ArrayList <Vehiculo>();
        ArrayList <Empresa> listaEmpresas = new ArrayList <Empresa>();
        ArrayList <Producto> listaProductos = new ArrayList <Producto>();
        ArrayList <Servicio> listaServicios = new ArrayList <Servicio>();
        ArrayList <Trabajador> listaTrabajadores = new ArrayList <Trabajador>();
        
    Vehiculo c1 = new Vehiculo("ABC123", "Negro", 2016, "Honda");
    Vehiculo c2 = new Vehiculo("BCD123", "Azul", 2019, "BMW");
    Vehiculo c3 = new Vehiculo("CDE123", "Rojo", 2023, "Chevloret");
            
            System.out.println(c1);
            System.out.println("--------------------------------");
            System.out.println(c2);
            System.out.println("--------------------------------");
            System.out.println(c3);
            System.out.println("--------------------------------");       
    
            
        listaVehiculos.add(c1);
        listaVehiculos.add(c2);
        listaVehiculos.add(c3);
        
        VehiculoCrud crudVehiculo = new VehiculoCrud();
        
        int total = crudVehiculo.agregarCarro(c3);
        System.out.println("Total: " + total);
        total = crudVehiculo.agregarCarro(c2);
        System.out.println("total: " + total);
        total = crudVehiculo.agregarCarro(c1);
        System.out.println("total: " + total);
        System.out.println("-------------------------------");
        
        Vehiculo c = crudVehiculo.buscarCarro("ABC123");
        System.out.println("Carro encontrado");
        System.out.println(c);
        System.out.println("-------------------------------");
        
        Vehiculo nuevoCarro = new Vehiculo("DEF123", "verde", 2021, "Nisan");
        crudVehiculo.actualizarCarro("ABC123", nuevoCarro);
        
        Vehiculo CarroActualizado = crudVehiculo.buscarCarro("ABC123");
        System.out.println("-------------------------------");
        System.out.println("Carro Actualizado");
        System.out.println("-------------------------------");
        System.out.println(CarroActualizado);
        System.out.println("-------------------------------");
        
        try{
            crudVehiculo.borrarCarro("ABC123");
            System.out.println("Carro borrado");
        }   catch (Exception errorBorrar){
            System.out.println("No se pudo borrar el carro: " + errorBorrar.getMessage());
        }
        
        System.out.println("-------------------------------");
        
    Empresa e1 = new Empresa("PRODUCTOX", "EMPRESA1", 1.1, LocalDate.of(2024, Month.MARCH, 10), 11111);
    Empresa e2 = new Empresa("PRODUCTOY", "EMPRESA2", 1.2, LocalDate.of(2024, Month.MARCH, 13),11112);
    Empresa e3 = new Empresa("PRODUCTOZ", "EMPRESA3", 1.3, LocalDate.of(2024, Month.MARCH, 23),11113);
            
            System.out.println(e1);
            System.out.println("--------------------------------");
            System.out.println(e2);
            System.out.println("--------------------------------");
            System.out.println(e3);
            System.out.println("--------------------------------");       
    
            
        listaEmpresas.add(e1);
        listaEmpresas.add(e2);
        listaEmpresas.add(e3);
        
        EmpresaCrud crudEmpresa = new EmpresaCrud();
        
        total = crudEmpresa.agregarEmpresa(e3);
        System.out.println("Total: " + total);
        total = crudEmpresa.agregarEmpresa(e2);
        System.out.println("total: " + total);
        total = crudEmpresa.agregarEmpresa(e1);
        System.out.println("total: " + total);
        System.out.println("-------------------------------");
        
        Empresa e = crudEmpresa.buscarEmpresa(11111);
        System.out.println("Empresa encontrada");
        System.out.println(e);
        System.out.println("-------------------------------");
        
        Empresa nuevaEmpresa = new Empresa("PRODUCTOA", "EMPRESA4", 1.4, LocalDate.of(2024, Month.MARCH, 30), 11114);
        crudEmpresa.actualizarEmpresa(11111, nuevaEmpresa);
        
        Empresa EmpresaActualizada = crudEmpresa.buscarEmpresa(11111);
        System.out.println("-------------------------------");
        System.out.println("Empresa Actualizada");
        System.out.println("-------------------------------");
        System.out.println(EmpresaActualizada);
        System.out.println("-------------------------------");
        
        try{
            crudEmpresa.borrarEmpresa(11111);
            System.out.println("Empresa borrada");
        }   catch (Exception errorBorrar){
            System.out.println("No se pudo borrar la empresa: " + errorBorrar.getMessage());
        }
        
        System.out.println("-------------------------------");
        
        
    Producto p1 = new Producto("PRODUCTO1", 1.1, 1, LocalDate.of(2025, Month.APRIL,14));
    Producto p2 = new Producto("PRODUCTO2", 1.2, 2,LocalDate.of(2025, Month.APRIL,17));
    Producto p3 = new Producto("PRODUCTO3", 1.3, 3,LocalDate.of(2025, Month.APRIL,22));
            
            System.out.println(p1);
            System.out.println("--------------------------------");
            System.out.println(p2);
            System.out.println("--------------------------------");
            System.out.println(p3);
            System.out.println("--------------------------------");       
    
            
        listaProductos.add(p1);
        listaProductos.add(p2);
        listaProductos.add(p3);
        
        ProductoCrud crudProducto = new ProductoCrud();
        
        total = crudProducto.agregarProducto(p3);
        System.out.println("Total: " + total);
        total = crudProducto.agregarProducto(p2);
        System.out.println("total: " + total);
        total = crudProducto.agregarProducto(p1);
        System.out.println("total: " + total);
        System.out.println("-------------------------------");
        
        Producto p = crudProducto.buscarProducto("PRODUCTO1");
        System.out.println("Prodcuto encontrado");
        System.out.println(p);
        System.out.println("-------------------------------");
        
        Producto nuevoProducto = new Producto("PRODUCTO4", 1.4, 4, LocalDate.of(2025, Month.APRIL, 24));
        crudProducto.actualizarProducto("PRODUCTO1", nuevoProducto);
        
        Producto ProductoActualizado = crudProducto.buscarProducto("PRODUCTO1");
        System.out.println("-------------------------------");
        System.out.println("Producto Actualizado");
        System.out.println("-------------------------------");
        System.out.println(ProductoActualizado);
        System.out.println("-------------------------------");
        
        try{
            crudProducto.borrarProducto("PRODUCTO1");
            System.out.println("Producto borrado");
        }   catch (Exception errorBorrar){
            System.out.println("No se pudo borrar el Producto: " + errorBorrar.getMessage());
        }
        
        System.out.println("-------------------------------");
        
    
    
    Trabajador t1 = new Trabajador(11111, "Juan", "Perez", LocalDate.of(1990, Month.JANUARY, 23), 1.4, "Gerente");
    Trabajador t2 = new Trabajador(11112, "Jose", "Gutierrez", LocalDate.of(2000, Month.MARCH, 15), 1.1, "Trabajador");
    Trabajador t3 = new Trabajador(11113, "Pedro", "Salgado", LocalDate.of(1998, Month.AUGUST, 03), 1.1, "Trabajador");
            
            System.out.println(t1);
            System.out.println("--------------------------------");
            System.out.println(t2);
            System.out.println("--------------------------------");
            System.out.println(t3);
            System.out.println("--------------------------------");       
    
            
        listaTrabajadores.add(t1);
        listaTrabajadores.add(t2);
        listaTrabajadores.add(t3);
        
        TrabajadorCrud crudTrabajador = new TrabajadorCrud();
        
        total = crudTrabajador.agregarTrabajador(t3);
        System.out.println("Total: " + total);
        total = crudTrabajador.agregarTrabajador(t2);
        System.out.println("total: " + total);
        total = crudTrabajador.agregarTrabajador(t1);
        System.out.println("total: " + total);
        System.out.println("-------------------------------");
        
        Trabajador t = crudTrabajador.buscarTrabajador(11111);
        System.out.println("Trabajador encontrado");
        System.out.println(t);
        System.out.println("-------------------------------");
        
        Trabajador nuevoTrabajador = new Trabajador(11114 ,"Diego", "Posada", LocalDate.of(1600, Month.MARCH, 27), 1.9, "Supervisor Encargado");
        crudTrabajador.actualizarTrabajador(11111, nuevoTrabajador);
        
        Trabajador TrabajadorActualizado = crudTrabajador.buscarTrabajador(11111);
        System.out.println("-------------------------------");
        System.out.println("STrabajador Actualizado");
        System.out.println("-------------------------------");
        System.out.println(TrabajadorActualizado);
        System.out.println("-------------------------------");
        
        try{
            crudTrabajador.borrarTrabajador(11111);
            System.out.println("Trabajador borrado");
        }   catch (Exception errorBorrar){
            System.out.println("No se pudo borrar el trabajador: " + errorBorrar.getMessage());
        }
        
        System.out.println("-------------------------------");

    Servicio s1 = new Servicio("SERVICIOX", 1.1, 23, "LAVADO GENERAL");
    Servicio s2 = new Servicio("SERVICIOY", 1.3, 90, "LAVADO, POLICHIDADO Y ENCERADO");
    Servicio s3 = new Servicio("SERVICIOZ", 1.2, 60, "LAVADO Y ENCERADO");
            
            System.out.println(e1);
            System.out.println("--------------------------------");
            System.out.println(e2);
            System.out.println("--------------------------------");
            System.out.println(e3);
            System.out.println("--------------------------------");       
    
            
        listaServicios.add(s1);
        listaServicios.add(s2);
        listaServicios.add(s3);
        
        ServicioCrud crudServicio = new ServicioCrud();
        
        total = crudServicio.agregarServicio(s3);
        System.out.println("Total: " + total);
        total = crudServicio.agregarServicio(s2);
        System.out.println("total: " + total);
        total = crudServicio.agregarServicio(s1);
        System.out.println("total: " + total);
        System.out.println("-------------------------------");
        
        Servicio s = crudServicio.buscarServicio("SERVICIOX");
        System.out.println("Servicio encontrada");
        System.out.println(s);
        System.out.println("-------------------------------");
        
        Servicio nuevoServicio = new Servicio("SERVICIOA", 1.4, 120, "TODO INCLUIDO");
        crudServicio.actualizarServicio("SERVICIOX", nuevoServicio);
        
        Servicio ServicioActualizado = crudServicio.buscarServicio("SERVICIOX");
        System.out.println("-------------------------------");
        System.out.println("Servicio Actualizado");
        System.out.println("-------------------------------");
        System.out.println(ServicioActualizado);
        System.out.println("-------------------------------");
        
        try{
            crudServicio.borrarServicio("SERVICIOX");
            System.out.println("Servicio borrada");
        }   catch (Exception errorBorrar){
            System.out.println("No se pudo borrar el servicio: " + errorBorrar.getMessage());
        }
        
        System.out.println("-------------------------------");
    }
    
}
