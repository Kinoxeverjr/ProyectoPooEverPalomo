package co.edu.ude.poo.LavaderoDeCarros.modelo.entidades;

import java.time.LocalDate;


public class Empresa {
    private String producto;
    private String nombreEmpresa;
    private double precioProductoEmpresa;
    private LocalDate fechaDeEntrega;
    private int numeroDeRegistro;

    public Empresa() {
    }

    public Empresa(String producto, String nombreEmpresa, double precioProductoEmpresa, LocalDate fechaDeEntrega, int numeroDeRegistro) {
        this.producto = producto;
        this.nombreEmpresa = nombreEmpresa;
        this.precioProductoEmpresa = precioProductoEmpresa;
        this.fechaDeEntrega = fechaDeEntrega;
        this.numeroDeRegistro = numeroDeRegistro;
    }

    public String getProducto() {
        return producto;
    }

    public void setProducto(String producto) {
        this.producto = producto;
    }

    public String getNombreEmpresa() {
        return nombreEmpresa;
    }

    public void setNombreEmpresa(String nombreEmpresa) {
        this.nombreEmpresa = nombreEmpresa;
    }

    public double getPrecioProductoEmpresa() {
        return precioProductoEmpresa;
    }

    public void setPrecioProductoEmpresa(double precioProductoEmpresa) {
        this.precioProductoEmpresa = precioProductoEmpresa;
    }

    public LocalDate getFechaDeEntrega() {
        return fechaDeEntrega;
    }

    public void setFechaDeEntrega(LocalDate fechaDeEntrega) {
        this.fechaDeEntrega = fechaDeEntrega;
    }

    public int getNumeroDeRegistro() {
        return numeroDeRegistro;
    }

    public void setNumeroDeRegistro(int numeroDeRegistro) {
        this.numeroDeRegistro = numeroDeRegistro;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Empresa{");
        sb.append("producto=").append(producto);
        sb.append(", nombreEmpresa=").append(nombreEmpresa);
        sb.append(", precioProductoEmpresa=").append(precioProductoEmpresa);
        sb.append(", fechaDeEntrega=").append(fechaDeEntrega);
        sb.append(", numeroDeRegistro=").append(numeroDeRegistro);
        sb.append('}');
        return sb.toString();
    }

}