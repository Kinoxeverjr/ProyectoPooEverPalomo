package co.edu.ude.poo.LavaderoDeCarros.modelo.crud;

import co.edu.ude.poo.LavaderoDeCarros.modelo.entidades.Vehiculo;
import java.util.ArrayList;
import java.util.List;


  public class VehiculoCrud {
    public static List<Vehiculo> listaCarros = new ArrayList<>();

        public int agregarCarro (Vehiculo carro) throws Exception {
            for (Vehiculo c : listaCarros){
                if (carro.getPlaca() == c.getPlaca() ) {
                    throw new Exception ("El Carro con placa : " + c.getPlaca() + "ya existe");
                }
            }
            listaCarros.add(carro);
            return listaCarros.size();
            
    }

public Vehiculo buscarCarro (String Placa) throws Exception {
    Vehiculo carro = null;
    for (Vehiculo c : listaCarros) {
        if (c.getPlaca() == Placa) {
            carro = c;
            break;
            }
    }
    if (carro == null){
    throw new Exception ("El carro con placa: " + Placa + "ya existe");
    }
    return carro;
        
}

public void borrarCarro (String Placa) throws Exception {
    Vehiculo carro = null;
    for (Vehiculo c : listaCarros) {
        if (c.getPlaca() == Placa) {
            carro= c;
            break;
        }
    }
    if (carro == null) {
        throw new Exception ("El carro de placa" + Placa + "no esta registrado");
        
    }
    listaCarros.remove(carro);
  }
        public void actualizarCarro(String Placa, Vehiculo nuevoCarro) throws Exception {
    Vehiculo carroOriginal = buscarCarro(Placa);
    if (carroOriginal != null) {
        carroOriginal.setColor(nuevoCarro.getColor());
        carroOriginal.setModelo(nuevoCarro.getModelo());
        carroOriginal.setMarca(nuevoCarro.getMarca());
    } else {
        throw new Exception("CARRO NO SE PUDO ACTUALIZAR");
    }
}

}




