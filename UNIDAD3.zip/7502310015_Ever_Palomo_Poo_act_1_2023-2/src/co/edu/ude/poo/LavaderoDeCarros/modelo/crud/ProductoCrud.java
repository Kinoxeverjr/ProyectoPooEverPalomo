package co.edu.ude.poo.LavaderoDeCarros.modelo.crud;

import co.edu.ude.poo.LavaderoDeCarros.modelo.entidades.Producto;
import java.util.ArrayList;
import java.util.List;


public class ProductoCrud {
    public static List<Producto> listaProductos = new ArrayList<>();

        public int agregarProducto (Producto producto) throws Exception {
            for (Producto p : listaProductos){
                if (producto.getNombreProducto() == p.getNombreProducto() ) {
                    throw new Exception ("El Producto "+ p.getNombreProducto() + "ya existe");
                }
            }
            listaProductos.add(producto);
            return listaProductos.size();
            
    }

public Producto buscarProducto (String NombreProducto) throws Exception {
    Producto producto = null;
    for (Producto p : listaProductos) {
        if (p.getNombreProducto() == NombreProducto) {
            producto = p;
            break;
            }
    }
    if (producto == null){
    throw new Exception ("El producto" + NombreProducto + "ya existe");
    }
    return producto;
        
}

public void borrarProducto (String NombreProducto) throws Exception {
    Producto producto = null;
    for (Producto p : listaProductos) {
        if (p.getNombreProducto() == NombreProducto) {
            producto = p;
            break;
        }
    }
    if (producto == null) {
        throw new Exception ("El producto" + NombreProducto + "no esta registrado");
        
    }
    listaProductos.remove(producto);
  }
public void actualizarProducto(String numeroDeProducto, Producto nuevoProducto) throws Exception {
    Producto productoOriginal = buscarProducto(numeroDeProducto);
    if (productoOriginal != null) {
        productoOriginal.setPrecioDelProducto(nuevoProducto.getPrecioDelProducto());
        productoOriginal.setFechaDeVencimiento(nuevoProducto.getFechaDeVencimiento());
    } else {
        throw new Exception("PRODUCTO NO SE PUDO ACTUALIZAR");
    }
    }
}


